from setuptools import setup
setup(
    name='chemtools-py',
    version='0.0.1',    
    description='A example Python package',
    long_description="somewhat in the future",
    url='https://github.com/KerrKerrKerr/chemtools-py',
    download_url="https://github.com/KerrKerrKerr/chemtools-py.git",
    author='burntSynaps3',
    author_email='ustinov2005@example.com',
    license='BRUH',
    packages=['chemtools-py'],
    install_requires=[
        
    ],
)

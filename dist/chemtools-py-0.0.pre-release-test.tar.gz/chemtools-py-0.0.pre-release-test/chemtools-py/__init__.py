from .funclib import get_elements,molar_mass,parse_chemical_formula
__author__ = "burntSynaps3"
__version__ = "0.0"
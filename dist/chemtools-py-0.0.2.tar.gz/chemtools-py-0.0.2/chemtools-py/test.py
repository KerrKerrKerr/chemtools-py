import re
from sympy import Matrix, lcm
from general_purpose_funtions import *
from balance_equasion import *
print(balance_equation(["KMnO4","H2SO4","C6H5CH3"],["K2SO4","MnSO4","C6H5COOH","H2O"]))
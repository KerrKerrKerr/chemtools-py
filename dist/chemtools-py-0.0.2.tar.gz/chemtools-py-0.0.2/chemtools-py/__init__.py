from .general_purpose_funtions import *
from .balance_equasion import balance_equation
__author__ = "burntSynaps3"
__version__ = "0.0.2"